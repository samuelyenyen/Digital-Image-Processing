(in linux)
make
(in windows)
g++ main.cpp Process_Bmp.cpp Image.cpp -o my_program
./my_program

(need g++)