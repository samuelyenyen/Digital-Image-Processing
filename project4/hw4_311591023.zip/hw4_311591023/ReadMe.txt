Run in Visual Studio with opencv
