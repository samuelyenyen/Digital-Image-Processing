(in linux)
make
(in windows)
g++ main.cpp -o my_program
./my_program

(need g++)